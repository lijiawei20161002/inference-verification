Independent H100 frozen capture, 18 October 2026
Capture SHA-256: 53985023de9acea63b76eaaa1c2183f4cc94917b95e49bf59597f6a6881e5bba
80 prompts x 256 positions, Qwen3-1.7B BF16. Built-in prompt bank only.
This is a NEW capture, not the unavailable A100 capture b63b7534....

Prepare a checkout at 5b5667c60f478403a4132c2c9744c6b1ef21988b.
The source.tar.gz contains the exact tracked runtime sources for overlaying that checkout.
Match the scoring software, CUDA runtime and thread flags in environment.json.
Cache the pinned model revision from model-refs.json before enabling offline mode.
From the checkout, set BUNDLE to the absolute extracted transfer directory, then run:

export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 CUDA_VISIBLE_DEVICES=0
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 TOKENIZERS_PARALLELISM=false
python -m experiments.exp_frozen_replay_gpu replay --node a100-replay \
  --capture "$BUNDLE/capture/capture.json.gz" --capture-sha256 53985023de9acea63b76eaaa1c2183f4cc94917b95e49bf59597f6a6881e5bba \
  --output "$BUNDLE/a100"
python -m experiments.exp_frozen_replay_gpu compare --baseline "$BUNDLE/h100" \
  --alternate "$BUNDLE/a100" --output "$BUNDLE/h100-a100-comparison.json"

Set HF_HOME to the prepared model cache. Output paths must not exist.
Positive d-prime in that comparison means higher scores on A100.
Hardware and driver changes are combined; this measures neither attack power nor deployment FPR.
